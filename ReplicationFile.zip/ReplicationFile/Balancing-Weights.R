library(foreign)
library(balancer)
library(dplyr)
library(ggplot2)

rm(list=ls())

rhc <- read.dta("./data/rhc_clean.dta")
                           
#####################################################
# Estimating IP weights
#####################################################

# Covariates For Adjustment
vars <- c("resp", "card", "neuro", "gastr", "renal", "meta", "hema", "seps", "trauma", 
			   "ortho", "adld3pc", "das2d3pc", "dnr1", "surv2md1", "aps1", "scoma1", "wtkilo1",
			   "temp1", "meanbp1", "resp1", "hrt1", "pafi1", "paco21", "ph1", "wblc1", "hema1",
			   "sod1", "pot1", "crea1", "bili1", "alb1", "cardiohx", "chfhx", "dementhx",
			   "psychhx", "chrpulhx", "renalhx", "liverhx", "gibledhx", "malighx", "immunhx",
			   "transhx", "amihx", "age", "edu", "ur_int", "race_cat1", "race_cat2",
			   "ins_cat1",  "ins_cat2",  "ins_cat3",  "ins_cat4",  "ins_cat5", 
			   "cat1_dum1", "cat1_dum2", "cat1_dum3", "cat1_dum4", "cat1_dum5",
               "cat1_dum6", "cat1_dum7", "cat1_dum8", "canc_cat1", "canc_cat2",
               "inc_cat1", "inc_cat2", "inc_cat3",
               "cat2_dum1", "cat2_dum2", "cat2_dum3", "cat2_dum4", "cat2_dum5",
               "cat2_dum6")
               
               
X <- scale(data[,vars])
trt <- data$treat
n <- nrow(data)
Z <- data$hospid
 
 # timing
t_fexact <- system.time({                
out.rhc <- multilevel_qp(X, trt, rep(1,n), lambda = 150, verbose= TRUE, exact_global = FALSE, scale_sample_size = FALSE)
})

# time required for computation, in minutes
t_fexact[['elapsed']]/60

# Process the Weights
data$wts <- pmax(out.rhc$weights, 0)
data$wts[data$treat == 1] <- 1

sum((data$wts > 10))

# ESS
nrow(data)
ess <- (sum(data$wts)^2) / (sum(data$wts^2)) 
ess

data.var <- data %>% group_by(treat) %>% 
   summarize(across(vars, ~var(.x))) %>% as.data.frame()

c.var <- as.numeric(data.var[1,])
t.var <- as.numeric(data.var[2,])
c.var <- c.var[-1]
t.var <- t.var[-1]
pooled.var <- sqrt((t.var + c.var/2))


um.wt <- data %>% group_by(treat) %>% 
   summarize(across(vars, ~mean(.x))) %>% as.data.frame()

bal.st <- data %>% group_by(treat) %>% 
   summarize(across(vars, ~ weighted.mean(.x, wts))) %>% as.data.frame()
               
um.wt.tab <- matrix(NA, length(vars), 3)
um.wt.tab[,1] <- unlist(um.wt[1,-1]) 
um.wt.tab[,2] <- unlist(um.wt[2,-1])                        
um.wt.tab[,3] <- (unlist(um.wt[2,-1]) - unlist(um.wt[1,-1]))/pooled.var

bal.st.tab <- matrix(NA, length(vars), 3)
bal.st.tab[,1] <- unlist(bal.st[1,-1]) 
bal.st.tab[,2] <- unlist(bal.st[2,-1])                        
bal.st.tab[,3] <- (unlist(bal.st[2,-1]) - unlist(bal.st[1,-1]))/pooled.var    


# Plots 
n_covs <- length(vars)             			  
data.plot <- c(bal.st.tab[,3], um.wt.tab[,3])
data.plot <- as.data.frame(data.plot)
names(data.plot) <- "std.dif"
data.plot$contrast <- c(rep(1, n_covs), rep(2, n_covs))
data.plot$contrast <- factor(data.plot$contrast, levels = c(1,2), labels = c("Weighted", "Unweighted"))
data.plot$covariate <- as.factor(vars)

library(ggplot2)
	
ggplot(data=data.plot, aes(x=std.dif, y=covariate, shape=factor(contrast)))  + 
          geom_point(size=1.75) + 
          scale_shape_manual(name= "Contrast", values=c(1,15)) + 
          xlab("Standardized Difference") + ylab("Covariates") +
          scale_y_discrete(limits = rev(levels(data.plot$covariate))) +
          geom_vline(xintercept= 0) +
          geom_vline(xintercept= 0.1) +
          geom_vline(xintercept= -0.1) +
          theme_bw()

library(sandwich)
msm.out <- function(obj){
	SE <- sqrt(diag(vcovHC(obj, type="HC0")))[2] # robust standard errors
    beta <- coef(obj)[2]
    lcl <- (beta - abs(qnorm(.025))*SE)
    ucl <- (beta + abs(qnorm(.025))*SE)
    return(c(beta, lcl, ucl))
   }

# Risks
died <- lm(dead ~ treat, data=data, weights = wts)
died.out <- msm.out(died)
died.out


adjust.vars <-c("treat","resp", "card", "neuro", "gastr", "renal", "meta", "hema", "seps", "trauma", 
			   "ortho", "adld3pc", "das2d3pc", "dnr1", "surv2md1", "aps1", "scoma1", "wtkilo1",
			   "temp1", "meanbp1", "resp1", "hrt1", "pafi1", "paco21", "ph1", "wblc1", "hema1",
			   "sod1", "pot1", "crea1", "bili1", "alb1", "cardiohx", "chfhx", "dementhx",
			   "psychhx", "chrpulhx", "renalhx", "liverhx", "gibledhx", "malighx", "immunhx",
			   "transhx", "amihx", "age", "edu", "ur_int", "race_cat1", "race_cat2",
			   "ins_cat1",  "ins_cat2",  "ins_cat3",  "ins_cat4", 
			   "cat1_dum1", "cat1_dum2", "cat1_dum3", "cat1_dum4", "cat1_dum5",
               "cat1_dum6", "cat1_dum7", "canc_cat1", "canc_cat2",
               "inc_cat1", "inc_cat2",
               "cat2_dum1", "cat2_dum2", "cat2_dum3", "cat2_dum4", "cat2_dum5")

died.full <- lm(reformulate(adjust.vars, response="dead"), data=data, weights = wts)
died.fout <- msm.out(died.full)
died.fout






