library(foreign)
library(grf)

rm(list=ls())

rhc <- read.dta("./data/rhc_clean.dta")

covs <-c("resp", "card", "neuro", "gastr", "renal", "meta", "hema", "seps", "trauma", 
			   "ortho", "adld3pc", "das2d3pc", "dnr1", "surv2md1", "aps1", "scoma1", "wtkilo1",
			   "temp1", "meanbp1", "resp1", "hrt1", "pafi1", "paco21", "ph1", "wblc1", "hema1",
			   "sod1", "pot1", "crea1", "bili1", "alb1", "cardiohx", "chfhx", "dementhx",
			   "psychhx", "chrpulhx", "renalhx", "liverhx", "gibledhx", "malighx", "immunhx",
			   "transhx", "amihx", "age", "edu", "ur_int", "race_cat1", "race_cat2",
			   "ins_cat1",  "ins_cat2",  "ins_cat3",  "ins_cat4",  "ins_cat5", 
			   "cat1_dum1", "cat1_dum2", "cat1_dum3", "cat1_dum4", "cat1_dum5",
               "cat1_dum6", "cat1_dum7", "cat1_dum8", "canc_cat1", "canc_cat2",
               "inc_cat1", "inc_cat2", "inc_cat3",
               "cat2_dum1", "cat2_dum2", "cat2_dum3", "cat2_dum4", "cat2_dum5",
               "cat2_dum6")

###########################
# Mortality
###########################

use = rhc[,c("dead","treat",covs)]

#Remove Missing
use <- use[complete.cases(use),]
xt = use[,c(-1:-2)]
colnames(xt) <- NULL
nos <- seq(1:72)
colnames(xt) <- paste("x", nos, sep="")
xt <- as.matrix(xt)
tau.forest = causal_forest(xt, use$dead, use$treat, tune.parameters = "all")
RF.out <- average_treatment_effect(tau.forest, target.sample = "treated", method = "TMLE")

pe <- RF.out[1]
sd <- RF.out[2]
ci.1 <- pe-1.96*sd
ci.2 <- pe+1.96*sd

c(pe, ci.1, ci.2)
