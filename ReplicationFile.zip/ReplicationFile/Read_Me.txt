

So Many Choices: A Guide to Selecting Among Methods to Adjust For Observed Confounders
Luke Keele and Richard Grieve
Jan 3, 2025

This document describes the replication files for the above paper. The archive contains all of the programs used in the analysis. 

Application

For this paper, we include the data in the replication file along with all the R scripts. The title of each R script corresponds
to the method used for estimation.  The following order replicates the order of the results in the text.

1. RegAdjustment.R
2. G-Formula.R
3. IPWeighting.R
4. Matching.R
5. Balancing-Weights.R
6. RandomForest.R
7. TMLE-SL.R
8. Interaction-Detect.R
9. Balancing-Weights-Expand-Basis.R





 