library(foreign)
library(balancer)
library(dplyr)
library(ggplot2)

rm(list=ls())

setwd("/Users/ljk20/Dropbox/Stat Adj Essay/data")
data <- read.dta("rhc_clean.dta")

head(data)
table(data$treat)


set.seed(1031)
train <- sample(nrow(data), round(.25*nrow(data)))
data <- data[-train, ]
                              
#####################################################
# Estimating IP weights
#####################################################

# Covariates For Adjustment
vars <- c("resp", "card", "neuro", "gastr", "renal", "meta", "hema", "seps", "trauma", 
			   "ortho", "adld3pc", "das2d3pc", "dnr1", "surv2md1", "aps1", "scoma1", "wtkilo1",
			   "temp1", "meanbp1", "resp1", "hrt1", "pafi1", "paco21", "ph1", "wblc1", "hema1",
			   "sod1", "pot1", "crea1", "bili1", "alb1", "cardiohx", "chfhx", "dementhx",
			   "psychhx", "chrpulhx", "renalhx", "liverhx", "gibledhx", "malighx", "immunhx",
			   "transhx", "amihx", "age", "edu", "ur_int", "race_cat1", "race_cat2",
			   "ins_cat1",  "ins_cat2",  "ins_cat3",  "ins_cat4",  "ins_cat5", 
			   "cat1_dum1", "cat1_dum2", "cat1_dum3", "cat1_dum4", "cat1_dum5",
               "cat1_dum6", "cat1_dum7", "cat1_dum8", "canc_cat1", "canc_cat2",
               "inc_cat1", "inc_cat2", "inc_cat3","cat2_dum1", "cat2_dum2", 
               "cat2_dum3", "cat2_dum4", "cat2_dum5","cat2_dum6",
               "pafi1:hema1", "pafi1:resp1", "crea1:surv2md1", "crea1:temp1",
               "crea1:meanbp1", "crea1:das2d3pc", "resp1:pot1", "resp1:paco21",
               "resp1:surv2md1", "resp1:aps1", "meanbp1:adld3pc", "wtkilo1:meanbp1",
               "wtkilo1:hema1", "-1")
               
               
basis <- reformulate(vars)                        
X <- scale(model.matrix(as.formula(basis), data))
trt <- data$treat
n <- nrow(data)
                
out.rhc <- multilevel_qp(X, trt, rep(1,n), lambda = 150, verbose= TRUE, exact_global = FALSE, scale_sample_size = FALSE)

# Process the Weights
data$wts <- pmax(out.rhc$weights, 0)
data$wts[data$treat == 1] <- 1


library(sandwich)
msm.out <- function(obj){
	SE <- sqrt(diag(vcovHC(obj, type="HC0")))[2] # robust standard errors
    beta <- coef(obj)[2]
    lcl <- (beta - abs(qnorm(.025))*SE)
    ucl <- (beta + abs(qnorm(.025))*SE)
    return(c(beta, lcl, ucl))
   }

# Risks
died <- lm(dead ~ treat, data=data, weights = wts)
died.out <- msm.out(died)
died.out


adjust.vars <-c("resp", "card", "neuro", "gastr", "renal", "meta", "hema", "seps", "trauma", 
			   "ortho", "adld3pc", "das2d3pc", "dnr1", "surv2md1", "aps1", "scoma1", "wtkilo1",
			   "temp1", "meanbp1", "resp1", "hrt1", "pafi1", "paco21", "ph1", "wblc1", "hema1",
			   "sod1", "pot1", "crea1", "bili1", "alb1", "cardiohx", "chfhx", "dementhx",
			   "psychhx", "chrpulhx", "renalhx", "liverhx", "gibledhx", "malighx", "immunhx",
			   "transhx", "amihx", "age", "edu", "ur_int", "race_cat1", "race_cat2",
			   "ins_cat1",  "ins_cat2",  "ins_cat3",  "ins_cat4",  "ins_cat5", 
			   "cat1_dum1", "cat1_dum2", "cat1_dum3", "cat1_dum4", "cat1_dum5",
               "cat1_dum6", "cat1_dum7", "cat1_dum8", "canc_cat1", "canc_cat2",
               "inc_cat1", "inc_cat2", "inc_cat3","cat2_dum1", "cat2_dum2", 
               "cat2_dum3", "cat2_dum4", "cat2_dum5","cat2_dum6",
               "pafi1:hema1", "pafi1:resp1", "crea1:surv2md1", "crea1:temp1",
               "crea1:meanbp1", "crea1:das2d3pc", "resp1:pot1", "resp1:paco21",
               "resp1:surv2md1", "resp1:aps1", "meanbp1:adld3pc", "wtkilo1:meanbp1",
               "wtkilo1:hema1")
               
               
died.full <- lm(reformulate(adjust.vars, response="dead"), data=data, weights = wts)
died.fout <- msm.out(died.full)
died.fout



