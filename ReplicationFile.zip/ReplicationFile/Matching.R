library(foreign)
library(lmtest)
library(sandwich)
library(descr)
library(multcomp)
library(optmatch)
library(rcbalance)

rm(list=ls())

# Read in Additional Functions
source("./functions/coeftest.cluster.R")

rhc <- read.dta("./data/rhc_clean.dta")

# Covariates For Adjustment
covs <-c("treat","resp", "card", "neuro", "gastr", "renal", "meta", "hema", "seps", "trauma", 
			   "ortho", "adld3pc", "das2d3pc", "dnr1", "surv2md1", "aps1", "scoma1", "wtkilo1",
			   "temp1", "meanbp1", "resp1", "hrt1", "pafi1", "paco21", "ph1", "wblc1", "hema1",
			   "sod1", "pot1", "crea1", "bili1", "alb1", "cardiohx", "chfhx", "dementhx",
			   "psychhx", "chrpulhx", "renalhx", "liverhx", "gibledhx", "malighx", "immunhx",
			   "transhx", "amihx", "age", "edu", "ur_int", "race_cat1", "race_cat2",
			   "ins_cat1",  "ins_cat2",  "ins_cat3",  "ins_cat4",  "ins_cat5", 
			   "cat1_dum1", "cat1_dum2", "cat1_dum3", "cat1_dum4", "cat1_dum5",
               "cat1_dum6", "cat1_dum7", "cat1_dum8", "canc_cat1", "canc_cat2",
               "inc_cat1", "inc_cat2", "inc_cat3",
               "cat2_dum1", "cat2_dum2", "cat2_dum3", "cat2_dum4", "cat2_dum5",
               "cat2_dum6")
                           
## Matching
# Build Distance Matrix
# Add caliper and exact match on cat1 variable.
vars <- covs[-1]
my.dist <- build.dist.struct(z=rhc$treat == 1, X=rhc[vars],
                             calip.option = "propensity", 
                             caliper = 0.05)

# coarsen continuous health scores
rhc$highApache <- rhc$aps1 > mean(rhc$aps1)
rhc$highBps <- rhc$meanbp1 > mean(rhc$meanbp1)
rhc$highPafi <- rhc$pafi1 > mean(rhc$pafi1)

#define fine balance levels - by order of balance priority.
l1 <- c("highApache")
l2 <- c(l1, "highBps","highPafi")
l3 <- c(l2,"neuro", "card")


# Exclude Treated Units
t_fexact <- system.time({
match.out <- rcbalance(my.dist, fb.list = list(l1,l2,l3),
                         treated.info = rhc[rhc$treat == 1,],
                         control.info = rhc[rhc$treat != 1,], 
                         exclude.treated = TRUE, tol = .001)
})

# time required for the p-value computation, in minutes
t_fexact[['elapsed']]/60

## FYI .3 of a minute
##########################
#Post Match Processing
##########################

# Separate Original Data
t.dat <- rhc[rhc$treat==1,]
c.dat <- rhc[rhc$treat==0,]

# Extract Matched Treated
match.treat <- t.dat[as.numeric(rownames(match.out$matches)),]
n <- nrow(match.treat)

# Create Pair Id
match.treat$pair.id <- 1:n

# Extract Matched Controls
match.ctrl <- c.dat[match.out$matches,]
match.ctrl$pair.id <- 1:n

# Put Matched Data Back Together
match.data <- rbind(match.treat, match.ctrl)


##########################
# Outcome Analysis
##########################

clus.ci <- function(obj, alpha = .05){
  pe <- obj[2,1]
  se <- obj[2,2]
  q = qnorm(1-alpha/2)
  ci.l <- pe - se*q
  ci.u <- pe + se*q
  list(ci.l= ci.l, ci.u=ci.u)
}

# Via Regression - Cluster SEs on Matched Pairs
reg <- lm(dead ~ treat, data=match.data)
coeftest.cluster(match.data, reg, cluster1="pair.id")


vars <- c("treat","resp", "card", "neuro", "gastr", "renal", "meta", "hema", "seps", "trauma", 
			   "ortho", "adld3pc", "das2d3pc", "dnr1", "surv2md1", "aps1", "scoma1", "wtkilo1",
			   "temp1", "meanbp1", "resp1", "hrt1", "pafi1", "paco21", "ph1", "wblc1", "hema1",
			   "sod1", "pot1", "crea1", "bili1", "alb1", "cardiohx", "chfhx", "dementhx",
			   "psychhx", "chrpulhx", "renalhx", "liverhx", "gibledhx", "malighx", "immunhx",
			   "transhx", "amihx", "age", "edu", "ur_int", "race_cat1", "race_cat2",
			   "ins_cat1",  "ins_cat2",  "ins_cat3",  "ins_cat4",  "ins_cat5", 
			   "cat1_dum1", "cat1_dum2", "cat1_dum3", "cat1_dum4", "cat1_dum5",
               "cat1_dum6", "cat1_dum7", "cat1_dum8", "canc_cat1", "canc_cat2",
               "inc_cat1", "inc_cat2", "inc_cat3",
               "cat2_dum1", "cat2_dum2", "cat2_dum3", "cat2_dum4", "cat2_dum5",
               "cat2_dum6")

frmla <- as.formula(paste("dead ~", paste(vars, collapse = "+"), sep=""))
reg2 <- lm(frmla, data=match.data)
coeftest.cluster(match.data, reg2, cluster1="pair.id")[2,]
clus.out <- coeftest.cluster(match.data, reg2, cluster1="pair.id")
round(clus.out[2,], 3)





