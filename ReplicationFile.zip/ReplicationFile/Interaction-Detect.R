


### Packages
library("vivid") # for visualisations
library("ISLR") # for data
#library("randomForest") # to create model
library("condvis2") # for predict function
library(foreign)
library(tidymodels)
library("ranger")
library(doParallel)

rm(list=ls())

rhc <- read.dta("./data/rhc_clean.dta")


set.seed(1031)
train <- sample(nrow(data), round(.25*nrow(data)))
data.train <- data[train, ]
data.test <- data[-train, ]


nrow(data.train)
table(data.train$afam)

## Estimate Random Forest
vars <- c("resp", "card", "neuro", "gastr", "renal", "meta", "hema", "seps", "trauma", 
			   "ortho", "adld3pc", "das2d3pc", "dnr1", "surv2md1", "aps1", "scoma1", "wtkilo1",
			   "temp1", "meanbp1", "resp1", "hrt1", "pafi1", "paco21", "ph1", "wblc1", "hema1",
			   "sod1", "pot1", "crea1", "bili1", "alb1", "cardiohx", "chfhx", "dementhx",
			   "psychhx", "chrpulhx", "renalhx", "liverhx", "gibledhx", "malighx", "immunhx",
			   "transhx", "amihx", "age", "edu", "ur_int", "race_cat1", "race_cat2",
			   "ins_cat1",  "ins_cat2",  "ins_cat3",  "ins_cat4",  "ins_cat5", 
			   "cat1_dum1", "cat1_dum2", "cat1_dum3", "cat1_dum4", "cat1_dum5",
               "cat1_dum6", "cat1_dum7", "cat1_dum8", "canc_cat1", "canc_cat2",
               "inc_cat1", "inc_cat2", "inc_cat3",
               "cat2_dum1", "cat2_dum2", "cat2_dum3", "cat2_dum4", "cat2_dum5",
               "cat2_dum6")

data.est = data.train[,c("treat",vars)]


tree_rec <- recipe(treat ~ ., data = data.est)
tree_prep <- prep(tree_rec)
juiced <- juice(tree_prep)

tune_spec <- rand_forest(
             mtry = tune(),
             trees = 1000,
             min_n = tune()
             ) %>%
             set_mode("regression") %>%
             set_engine("ranger")
             
tune_wf <- workflow() %>%
           add_recipe(tree_rec) %>%
           add_model(tune_spec)
           
set.seed(343)
tree_folds <- vfold_cv(data.train)

doParallel::registerDoParallel()

set.seed(321)

t_fexact <- system.time({ 
tune_res <- tune_grid(
            tune_wf,
            resamples = tree_folds,
            grid= 20) 
})

t_fexact[['elapsed']]/60


rf_grid <- grid_regular(
           mtry(range = c(1, 20)),
           min_n(range = c(4,60)),
           levels = 5)

regular_res <- tune_grid(
               tune_wf,
               resamples = tree_folds,
               grid = rf_grid)
            
             
best_rmse <- select_best(tune_res, "rmse")
best_rmse
        	
best_rmse <- select_best(regular_res, "rmse")
best_rmse

final_rf <- finalize_model(
            tune_spec,
            best_rmse)

final_rf

            
## Model fitting:
# Fit a random forest model
set.seed(101)
rf <- ranger(treat ~ ., data = data.est, mtry = 4, min.node.size = 20, importance = "impurity")

set.seed(3456)
vividMatrixRF <- vivi(data.est, 
                      rf, "treat",
                      gridSize = 10, 
                      reorder = FALSE)
                      
                    
# Sort matrix:
vividMatrixRFSorted <- vividReorder(vividMatrixRF)

viviHeatmap(vividMatrixRFSorted, angle = 45) # sorted heatmap

# More Refined Interaction Identification
viviNetwork(vividMatrixRFSorted)

intVals <- as.dist(vividMatrixRFSorted)
intVals <- as.matrix(intVals)

sv <- which(diag(vividMatrixRFSorted) > 5 | apply(intVals, 1, max) > .01)
h <- hclust(-as.dist(vividMatrixRFSorted[sv,sv]), method="single")

viviNetwork(vividMatrixRFSorted[sv,sv],
			removeNode = T,
			cluster = cutree(h,3))
		
